import socket
import random
from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad

def generadorLlaves(p, g):
    llavePrivada = random.randint(1, p - 1)
    llavePublica = (g ** llavePrivada) % p
    return llavePrivada, llavePublica

def creaLlaveCompartida(llavePlublicaServer, llavePrivada, p):
    llaveCompartida = (llavePlublicaServer ** llavePrivada) % p
    return llaveCompartida

def mensajeCifrado(mensaje, llave):
    # Convertir la clave a bytes
    llave_bytes = llave.to_bytes(8, byteorder='big')
    cifrado = DES.new(llave_bytes, DES.MODE_ECB)
    textoCifrado = cifrado.encrypt(pad(mensaje.encode(), DES.block_size))
    return textoCifrado


# Configuración del cliente
host = '127.0.0.1'
port = 5555

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((host, port))

# Recibir clave pública del servidor
llavePublicaServer = int(client_socket.recv(1024).decode())

# Generar clave Diffie-Hellman y enviar clave pública al servidor
llavePrivada, llavePublica = generadorLlaves(llavePublicaServer, 5)
client_socket.send(str(llavePublica).encode())

# Calcular la clave compartida
llaveCompartida = creaLlaveCompartida(llavePublicaServer, llavePrivada, 23)

# Leer el mensaje desde el archivo 'mensajeentrada.txt'
archivo = open('mensajeentrada.txt', 'r')
mensajeEnviado = archivo.read()
archivo.close()

# Enviar el mensaje cifrado al servidor
mensajeEncriptado = mensajeCifrado(mensajeEnviado, llaveCompartida)
client_socket.send(mensajeEncriptado)

# Cerrar la conexión
client_socket.close()
