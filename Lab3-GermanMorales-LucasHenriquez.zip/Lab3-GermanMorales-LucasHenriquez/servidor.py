import socket
import random
from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad

def generarLlave():
    p = 23
    g = 5
    llavePrivada = random.randint(1, p - 1)
    llavePublica = (g ** llavePrivada) % p
    return llavePrivada, llavePublica, p, g

def llaveCompartida(llavePublicaCliente, llavePrivada, p):
    llaveCompartida = (llavePublicaCliente ** llavePrivada) % p
    return llaveCompartida

def encriptar(mensaje, llave):
    cifrado = DES.new(llave, DES.MODE_ECB)
    textoCifrado = cifrado.encrypt(pad(mensaje.encode(), DES.block_size))
    return textoCifrado

def decriptar(textoCifrado, llave):
    cifrado = DES.new(llave, DES.MODE_ECB)
    mensajeDescifrado = unpad(cifrado.decrypt(textoCifrado), DES.block_size)
    return mensajeDescifrado.decode()

# Configuración del servidor
host = '127.0.0.1'
port = 5555

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((host, port))
server_socket.listen(1)

print(f"Servidor escuchando en {host}:{port}")

client_socket, client_address = server_socket.accept()
print(f"Conexión entrante desde {client_address}")

# Generar clave Diffie-Hellman y enviar clave pública al cliente
llavePrivada, llavePublica, p, g = generarLlave()
client_socket.send(str(llavePublica).encode())

# Recibir clave pública del cliente
llavePublicaCliente = int(client_socket.recv(1024).decode())

## Calcular la clave compartida
llaveCompartida = llaveCompartida(llavePublicaCliente, llavePrivada, p)
print(f"Clave compartida derivada: {llaveCompartida}")

# Convertir la clave compartida a bytes
llaveCompartida_bytes = llaveCompartida.to_bytes(8, byteorder='big')

# Recibir mensaje cifrado desde el cliente
mensajeEncriptado = client_socket.recv(1024)
print(f"Mensaje cifrado recibido: {mensajeEncriptado}")

# Descifrar el mensaje
mensajeDecriptado = decriptar(mensajeEncriptado, llaveCompartida_bytes)
print(f"Mensaje descifrado: {mensajeDecriptado}")

# Guardar el mensaje descifrado en el archivo 'mensajerecibido.txt'
# Abrir el archivo en modo escritura
with open('mensajerecibido.txt', 'w') as file:
    file.write(mensajeDecriptado)

# Cerrar la conexión
client_socket.close()
server_socket.close()
